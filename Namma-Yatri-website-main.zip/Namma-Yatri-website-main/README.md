# Namma-Yatri-website

# Project For the Namma Yatri Open Mobility Challenge.

Team Members : 
* Raj Motwani
* Shivam Gupta
* Harsh Agrawal



 
A Web-App made to ease the booking system without the use of smartphone app with the help of Namma Yatri Chat Bot integerated in the website.

The ChatBot is also deployed in WhatsApp so the user can book using WhatAapp chat also.

Website Link https://thunderous-gingersnap-8c0c52.netlify.app/


